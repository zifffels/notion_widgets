import { Stopwatch } from "src/components/Stopwatch";

export default function App() {
  return <Stopwatch />;
}
