export const Second = 1000;
export const Minute = 60 * Second;
export const Hour = 60 * Minute;
